import './App.css';	
import Red from './components/Red';  
import Blue from './components/Blue';
import Center from './components/Center';
import { useState } from 'react';

var turnNumber = 0; // 현재 턴 번호 (0부터 시작) 

function App() {	
  // const [turnNumber, setTurnNumber] = useState(0); // 현재 턴 번호 상태 관리 (0부터 시작)

  const [mode, setMode] = useState('hope'); // 현재 모드 상태 관리 ( mode: 'hope' | 'ban' | 'select' | 'end' )
  // 상태값들
  // 1. 희망 목록
  const [hopeChampions, setHopeChampions] = useState([]); // 희망 챔피언 목록
  // 2. 밴 목록
  const [banChampions, setBanChampions] = useState([]); // 밴 챔피언 목록
  // 3. 선택 목록
  const [selectChampions, setSelectChampions] = useState([]); // 선택 챔피언 목록

  // ✅ Array.prototype.filter() 기능 설명
  // 📌 기본 구조
  // const result = array.filter(callback);
  //
  // array를 순회하면서
  // callback 함수의 반환값이 true인 요소만 남기고, false인 요소는 제거
  // 결과는 원본 배열을 변경하지 않고, 새 배열로 반환
  function pick(targetChampion) {
    console.log(`챔피언 ${targetChampion.name} 선택됨 : 현재 턴 no: ${turnNumber}`);
    //todo
    //모드별로 분기해야함
    if(mode === 'hope') { // 희망 챔피언 선택 모드. 플레이어 바에 희망 챔피언을 표시
      // 희망 챔피언을 선택했을 때의 로직
      // 중복 선택 가능
      // 선택한 희망 챔피언을 희망 목록에 추가. 희망 목록은 프룹스로 전달되어 갱신됨.
      setHopeChampions(prevHopeChampions => [...prevHopeChampions, targetChampion]);
    } else if(mode === 'ban') {
      // 밴 챔피언을 선택했을 때의 로직
      // 중복 선택 불가 (todo: 일단 희망로직과 동일하게 처리)
      // 선택한 희망 챔피언을 희망 목록에 추가. 희망 목록은 프룹스로 전달되어 갱신됨.
      setBanChampions(prevBanChampions => [...prevBanChampions, targetChampion]);

      //todo
      //수정해야함
      // 선택한 챔피언을 champions 목록에서 제거
      // 챔피언 보여주는 목록이 3모드 마다 달라져야할듯

      // setChampions(prevChampions =>
      //   prevChampions.filter(c => c.number !== targetChampion.number)
      // );
    } else if(mode === 'select') {
      // 플레이하려는 챔피언을 선택했을 때의 로직
      // 중복 선택 불가 (todo: 일단 희망로직과 동일하게 처리)
      // 선택한 희망 챔피언을 희망 목록에 추가. 희망 목록은 프룹스로 전달되어 갱신됨.
      setSelectChampions(prevSelectChampions => [...prevSelectChampions, targetChampion]);
    }

    // setTurnNumber(turnNumber + 1);  // 턴 번호 증가
    turnNumber = turnNumber + 1; // 턴 번호 증가
    if(mode === 'hope' && turnNumber > 9) {
      setMode('ban'); // 다 돌았으면 2.밴 모드로 전환
      // setTurnNumber(0); // 턴 번호 초기화
      turnNumber = 0; // 턴 번호 초기화
      console.log('모드 변경: 희망 -> 밴');
    }
    if(mode === 'ban' && turnNumber > 9) {
      setMode('select'); // 다 돌았으면 3.선택 모드로 전환
      // setTurnNumber(0); // 턴 번호 초기화
      turnNumber = 0; // 턴 번호 초기화
      console.log('모드 변경: 밴 -> 선택');
    }
    if(mode === 'select' && turnNumber > 9) {
      setMode('end'); // 다 돌았으면 4.백픽 종료로 전환
      // setTurnNumber(0); // 턴 번호 초기화
      turnNumber = 0; // 턴 번호 초기화
      console.log('모드 변경: 선택 -> 종료');
    }
  }

  const [champions, setChampions] = useState([
    {name: '가렌', number: 0},
    {name: '갈리오', number: 1},
    {name: '갱플랭크', number: 2},
    {name: '그라가스', number: 3},
    {name: '그레이브즈', number: 4},
    {name: '그웬', number: 5},
    {name: '나르', number: 6},
    {name: '나미', number: 7},
    {name: '나서스', number: 8},
    {name: '나피리', number: 9},
    {name: '노틸러스', number: 10},
    {name: '녹턴', number: 11},
    {name: '누누와 윌럼프', number: 12},
    {name: '니달리', number: 13},
    {name: '니코', number: 14},
    {name: '닐라', number: 15},
    {name: '다리우스', number: 16},
    {name: '다이애나', number: 17},
    {name: '드레이븐', number: 18},
    {name: '라이즈', number: 19},
    {name: '라칸', number: 20},
    {name: '람머스', number: 21},
    {name: '럭스', number: 22},
    {name: '럼블', number: 23},
    {name: '레나타 글라스크', number: 24},
    {name: '레넥톤', number: 25},
    {name: '레오나', number: 26},
    {name: '렉사이', number: 27},
    {name: '렐', number: 28},
    {name: '렝가', number: 29},
    {name: '루시안', number: 30},
    {name: '룰루', number: 31},
    {name: '르블랑', number: 32},
    {name: '리 신', number: 33},
    {name: '리븐', number: 34},
    {name: '리산드라', number: 35},
    {name: '릴리아', number: 36},
    {name: '마스터 이', number: 37},
    {name: '마오카이', number: 38},
    {name: '말자하', number: 39},
    {name: '말파이트', number: 40},
    {name: '멜', number: 41},
    {name: '모데카이저', number: 42},
    {name: '모르가나', number: 43},
    {name: '문도 박사', number: 44},
    {name: '미스 포츈', number: 45},
    {name: '밀리오', number: 46},
    {name: '바드', number: 47},
    {name: '바루스', number: 48},
    {name: '바이', number: 49},
    {name: '베이가', number: 50},
    {name: '베인', number: 51},
    {name: '벡스', number: 52},
    {name: '벨베스', number: 53},
    {name: '벨코즈', number: 54},
    {name: '볼리베어', number: 55},
    {name: '브라움', number: 56},
    {name: '브라이어', number: 57},
    {name: '브랜드', number: 58},
    {name: '블라디미르', number: 59},
    {name: '블리츠크랭크', number: 60},
    {name: '비에고', number: 61},
    {name: '빅토르', number: 62},
    {name: '뽀삐', number: 63},
    {name: '사미라', number: 64},
    {name: '사이온', number: 65},
    {name: '사일러스', number: 66},
    {name: '샤코', number: 67},
    {name: '세나', number: 68},
    {name: '세라핀', number: 69},
    {name: '세주아니', number: 70},
    {name: '세트', number: 71},
    {name: '소나', number: 72},
    {name: '소라카', number: 73},
    {name: '쉔', number: 74},
    {name: '쉬바나', number: 75},
    {name: '스몰더', number: 76},
    {name: '스웨인', number: 77},
    {name: '스카너', number: 78},
    {name: '시비르', number: 79},
    {name: '신 짜오', number: 80},
    {name: '신드라', number: 81},
    {name: '신지드', number: 82},
    {name: '쓰레쉬', number: 83},
    {name: '아리', number: 84},
    {name: '아무무', number: 85},
    {name: '아우렐리온 솔', number: 86},
    {name: '아이번', number: 87},
    {name: '아지르', number: 88},
    {name: '아칼리', number: 89},
    {name: '아크샨', number: 90},
    {name: '아트록스', number: 91},
    {name: '아펠리오스', number: 92},
    {name: '알리스타', number: 93},
    {name: '암베사', number: 94},
    {name: '애니', number: 95},
    {name: '애니비아', number: 96},
    {name: '애쉬', number: 97},
    {name: '야스오', number: 98},
    {name: '에코', number: 99},
    {name: '엘리스', number: 100},
    {name: '오공', number: 101},
    {name: '오로라', number: 102},
    {name: '오른', number: 103},
    {name: '오리아나', number: 104},
    {name: '올라프', number: 105},
    {name: '요네', number: 106},
    {name: '요릭', number: 107},
    {name: '우디르', number: 108},
    {name: '우르곳', number: 109},
    {name: '워윅', number: 110},
    {name: '유미', number: 111},
    {name: '이렐리아', number: 112},
    {name: '이블린', number: 113},
    {name: '이즈리얼', number: 114},
    {name: '일라오이', number: 115},
    {name: '자르반 4세', number: 116},
    {name: '자야', number: 117},
    {name: '자이라', number: 118},
    {name: '자크', number: 119},
    {name: '잔나', number: 120},
    {name: '잭스', number: 121},
    {name: '제드', number: 122},
    {name: '제라스', number: 123},
    {name: '제리', number: 124},
    {name: '제이스', number: 125},
    {name: '조이', number: 126},
    {name: '직스', number: 127},
    {name: '진', number: 128},
    {name: '질리언', number: 129},
    {name: '징크스', number: 130},
    {name: '초가스', number: 131},
    {name: '카르마', number: 132},
    {name: '카밀', number: 133},
    {name: '카사딘', number: 134},
    {name: '카서스', number: 135},
    {name: '카시오페아', number: 136},
    {name: '카이사', number: 137},
    {name: '카직스', number: 138},
    {name: '카타리나', number: 139},
    {name: '칼리스타', number: 140},
    {name: '케넨', number: 141},
    {name: '케이틀린', number: 142},
    {name: '케인', number: 143},
    {name: '케일', number: 144},
    {name: '코그모', number: 145},
    {name: '코르키', number: 146},
    {name: '퀸', number: 147},
    {name: '크산테', number: 148},
    {name: '클레드', number: 149},
    {name: '키아나', number: 150},
    {name: '킨드레드', number: 151},
    {name: '타릭', number: 152},
    {name: '탈론', number: 153},
    {name: '탈리야', number: 154},
    {name: '탐 켄치', number: 155},
    {name: '트런들', number: 156},
    {name: '트리스타나', number: 157},
    {name: '트린다미어', number: 158},
    {name: '트위스티드 페이트', number: 159},
    {name: '트위치', number: 160},
    {name: '티모', number: 161},
    {name: '파이크', number: 162},
    {name: '판테온', number: 163},
    {name: '피들스틱', number: 164},
    {name: '피오라', number: 165},
    {name: '피즈', number: 166},
    {name: '하이머딩거', number: 167},
    {name: '헤카림', number: 168},
    {name: '흐웨이', number: 169},
  ]);

  return (	
    <div id="app_main">
      <Red hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions}/>
      <Center onClick={pick} champions={champions}>
        <h1>챔피언 선택[밴픽]</h1>
        <h4>LolBanpick v0.1.0</h4>
        <p>현재 모드: {mode}</p>
        <p>현재 턴: {turnNumber + 1}</p>
      </Center>
      <Blue hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions}/>
    </div>	
  );	
}	
export default App;	