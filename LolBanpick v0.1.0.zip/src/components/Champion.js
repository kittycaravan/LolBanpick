import './Champion.css';	
function Champion({onClick,champion}) {	
  return (	
    // <div className="champion" style={{backgroundImage: `url(/lolBanpick/resources/img/champions/champion (${championNumber}).jpg)`}}>
    <div onClick={()=>onClick(champion)}>
      <div className="champion" style={{backgroundImage: `url(/lolBanpick/resources/img/champions/c${champion.number}.jpg)`}}>
      </div>	
      <div className='champion_bot'>{champion.name}</div>
    </div>
  );	
}	
export default Champion;	