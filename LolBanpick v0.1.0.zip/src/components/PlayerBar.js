import './PlayerBar.css';	
import Champion from './Champion';
export default function PlayerBar({mode,now,no,hopeChampions,banChampions, selectChampions}) {	
  return (	
    <div className="player_bar_box">
      <p>&nbsp;{no+1}&nbsp;</p>
      <div className="player_bar_hope">
        희망:
        {hopeChampions[no] && <Champion champion={hopeChampions[no]} />}
      </div>
      <div className="player_bar_ban">
        밴:
        {banChampions[no] && <Champion champion={banChampions[no]} />}
      </div>
      <div className="player_bar_select">
        이거 할래요:
        {selectChampions[no] && <Champion champion={selectChampions[no]} />}
      </div>
    </div>	
  );	
}	