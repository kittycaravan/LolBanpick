import PlayerBar from './PlayerBar';
import './Blue.css';	
function Blue({hopeChampions, banChampions, selectChampions}) {	
return (	
  <div id="blue_box">
      <PlayerBar mode="red" now={0} no={1} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={2} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={5} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={6} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={9} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
  </div>	
);	
}	
export default Blue;	