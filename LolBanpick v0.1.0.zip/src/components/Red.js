import PlayerBar from './PlayerBar';
import './Red.css';
function Red({hopeChampions, banChampions, selectChampions}) {	
  return (	
    <div id="red_box">
      <PlayerBar mode="red" now={0} no={0} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={3} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={4} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={7} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
      <PlayerBar mode="red" now={0} no={8} hopeChampions={hopeChampions} banChampions={banChampions} selectChampions={selectChampions} />
    </div>	
  );	
}	
export default Red;	