import './Champions.css';	

import Champion from './Champion';
function Champions({onClick,champions}) {	
  return (	
    <div id="champions_box">
      {
        champions.map((champion, index) => 
          <Champion key={index} champion={champion} onClick={onClick}/>
        )
      }
    </div>	
  );	
}	
export default Champions;	