import './Center.css';	
import Champions from './Champions';
function Center({children,onClick,champions}) {	
  return (	
    <div id="center_box">
      <div id="info_box">
        {children}
      </div>
      <div id="characters_box">
        <Champions onClick={onClick} champions={champions}/>
      </div>	
    </div>
  );	
}	
export default Center;	